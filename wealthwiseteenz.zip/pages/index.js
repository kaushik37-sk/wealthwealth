
import Head from 'next/head'
import 'bootstrap/dist/css/bootstrap.min.css'

export default function Home() {
  return (
    <div>
      <Head>
        <title>WealthWiseTeenz</title>
        <meta name="description" content="Financial Literacy for Teens" />
      </Head>
      <main className="container py-5">
        <h1 className="text-center">Welcome to WealthWiseTeenz!</h1>
        <p className="text-center">Empowering Teens with Financial Knowledge.</p>
      </main>
    </div>
  )
}
